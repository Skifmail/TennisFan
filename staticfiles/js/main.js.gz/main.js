/**
 * TennisFan - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile navigation toggle
    const navToggle = document.getElementById('nav-toggle');
    const navMenuMobile = document.getElementById('nav-menu-mobile');

    if (navToggle && navMenuMobile) {
        navToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            navMenuMobile.classList.toggle('active');
            navToggle.classList.toggle('active');
        });

        document.addEventListener('click', function(e) {
            if (!navToggle.contains(e.target) && !navMenuMobile.contains(e.target)) {
                navMenuMobile.classList.remove('active');
                navToggle.classList.remove('active');
            }
        });

        navMenuMobile.querySelectorAll('.nav-menu-link').forEach(function(link) {
            link.addEventListener('click', function() {
                navMenuMobile.classList.remove('active');
                navToggle.classList.remove('active');
            });
        });
    }

    // User dropdown toggle (desktop hover + mobile click via .open)
    const userMenuToggle = document.getElementById('user-menu-toggle');
    const userDropdown = document.getElementById('user-dropdown');

    if (userMenuToggle && userDropdown) {
        const dropdown = userMenuToggle.closest('.nav-dropdown');
        if (dropdown) {
            userMenuToggle.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                const isOpen = dropdown.classList.contains('open');
                document.querySelectorAll('.nav-dropdown').forEach(function(d) {
                    d.classList.remove('open');
                });
                if (!isOpen) {
                    dropdown.classList.add('open');
                }
            });

            document.addEventListener('click', function(e) {
                if (!dropdown.contains(e.target)) {
                    dropdown.classList.remove('open');
                }
            });
        }
    }

    // Auto-hide alerts after 5 seconds
    document.querySelectorAll('.alert').forEach(function(el) {
        setTimeout(function() {
            el.style.transition = 'opacity 0.3s ease';
            el.style.opacity = '0';
            el.addEventListener('transitionend', function() {
                el.remove();
            }, { once: true });
        }, 5000);
    });

    // Smooth scroll for in-page anchor links
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId && targetId.length > 1) {
                e.preventDefault();
                const target = document.querySelector(targetId);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });

    // Карточки: появление снизу вверх по очереди слева направо
    var cards = document.querySelectorAll('.main .card, .main .match-card');
    var staggerMs = 100;
    var pendingReveal = false;

    function sortByPosition(nodes) {
        var arr = Array.prototype.slice.call(nodes);
        var rects = new Map();
        arr.forEach(function(el) { rects.set(el, el.getBoundingClientRect()); });
        return arr.sort(function(a, b) {
            var ra = rects.get(a), rb = rects.get(b);
            var rowA = Math.round(ra.top / 30), rowB = Math.round(rb.top / 30);
            if (rowA !== rowB) return rowA - rowB;
            return ra.left - rb.left;
        });
    }

    function revealBatch() {
        pendingReveal = false;
        var winH = window.innerHeight;
        var toReveal = [];
        cards.forEach(function(card) {
            if (card.classList.contains('card-in-view')) return;
            var r = card.getBoundingClientRect();
            if (r.top < winH + 60) toReveal.push(card);
        });
        if (toReveal.length === 0) return;
        toReveal = sortByPosition(toReveal);
        toReveal.forEach(function(card, i) {
            card.style.transitionDelay = (i * staggerMs) / 1000 + 's';
            card.classList.add('card-in-view');
            if (observer) observer.unobserve(card);
            card.addEventListener('transitionend', function onEnd() {
                card.removeEventListener('transitionend', onEnd);
                card.style.willChange = 'auto';
            }, { once: true });
        });
    }

    var observer = null;
    if (cards.length && 'IntersectionObserver' in window) {
        observer = new IntersectionObserver(function(entries) {
            var hasNew = entries.some(function(e) { return e.isIntersecting; });
            if (hasNew && !pendingReveal) {
                pendingReveal = true;
                requestAnimationFrame(revealBatch);
            }
        }, { rootMargin: '0px 0px -40px 0px', threshold: 0.01 });
        cards.forEach(function(card) {
            card.style.willChange = 'transform, opacity';
            observer.observe(card);
        });
        requestAnimationFrame(revealBatch);
    } else {
        cards.forEach(function(card) {
            card.classList.add('card-in-view');
        });
    }

    // Footer accordion (mobile): сворачиваемые секции
    document.querySelectorAll('.footer-section [data-footer-toggle]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var section = this.closest('.footer-section');
            if (!section) return;
            var isOpen = section.classList.toggle('is-open');
            this.setAttribute('aria-expanded', isOpen === true ? 'true' : 'false');
        });
    });
});
